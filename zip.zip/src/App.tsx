import React, { Suspense, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useLocalState } from "./lib/storage";
import { Loader2 } from "lucide-react";
import { AuthProvider, useAuth } from "./lib/auth";

const Dashboard = React.lazy(() => import("./routes/index"));
const BillingPage = React.lazy(() => import("./routes/billing"));
const CustomersPage = React.lazy(() => import("./routes/customers"));
const ExpensesPage = React.lazy(() => import("./routes/expenses"));
const GirviPage = React.lazy(() => import("./routes/girvi"));
const InventoryPage = React.lazy(() => import("./routes/inventory"));
const KarigarsPage = React.lazy(() => import("./routes/karigars"));
const PurchasesPage = React.lazy(() => import("./routes/purchases"));
const RepairsPage = React.lazy(() => import("./routes/repairs"));
const ReportsPage = React.lazy(() => import("./routes/reports"));
const SalesPage = React.lazy(() => import("./routes/sales"));
const SuppliersPage = React.lazy(() => import("./routes/suppliers"));
const GoldRatesPage = React.lazy(() => import("./routes/gold-rates"));
const OrdersPage = React.lazy(() => import("./routes/orders"));
const LedgerPage = React.lazy(() => import("./routes/ledger"));
const DuesPage = React.lazy(() => import("./routes/dues"));
const ForwardedShopsPage = React.lazy(() => import("./routes/forwarded-shops"));
const KarigarTasksPage = React.lazy(() => import("./routes/karigar-tasks"));
const NotificationsPage = React.lazy(() => import("./routes/notifications"));
const LoginPage = React.lazy(() => import("./routes/login"));
const CalculatorPage = React.lazy(() => import("./routes/calculator"));
const EmployeesPage = React.lazy(() => import("./routes/employees"));
const GstReportPage = React.lazy(() => import("./routes/gst-report"));
const CatalogPage = React.lazy(() => import("./routes/catalog"));
const SuperAdminLoginPage = React.lazy(() => import("./routes/superadmin-login"));
const SuperAdminDashboardPage = React.lazy(() => import("./routes/superadmin-dashboard"));
const SuperAdminLoginDebugPage = React.lazy(() => import("./superadmin-login-debug"));

const fallback = (
  <div className="flex h-screen w-full items-center justify-center text-muted-foreground">
    <Loader2 className="w-8 h-8 animate-spin" />
  </div>
);

function SuperAdminApp() {
  const { superAdminSession } = useAuth();
  return (
    <Routes>
<Route path="/superadmin/login" element={<SuperAdminLoginPage />} />
      <Route path="/superadmin/login-debug" element={<SuperAdminLoginDebugPage />} />
      <Route
        path="/superadmin"
        element={superAdminSession ? <SuperAdminDashboardPage /> : <Navigate to="/superadmin/login" replace />}
      />
      <Route path="/superadmin/*" element={<Navigate to="/superadmin" replace />} />
    </Routes>
  );
}

function ShopApp() {
  const { tenantSession, setTenantSession } = useAuth();
  const [authUser, setAuthUser] = useLocalState<any>("ajms.auth", null);

  useEffect(() => {
    if (!tenantSession && authUser) {
      setAuthUser(null);
    }
  }, [tenantSession]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!authUser && tenantSession) {
      setTenantSession(null);
    }
  }, [authUser]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!tenantSession || !authUser) {
    return (
      <Suspense fallback={fallback}>
        <LoginPage onLogin={(session) => setTenantSession(session)} />
      </Suspense>
    );
  }

  if (authUser.role === "karigar") {
    return (
      <Suspense fallback={fallback}>
        <Routes>
          <Route path="/karigar-tasks" element={<KarigarTasksPage />} />
          <Route path="*" element={<Navigate to="/karigar-tasks" replace />} />
        </Routes>
      </Suspense>
    );
  }

  return (
    <Suspense fallback={fallback}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/billing" element={<BillingPage />} />
        <Route path="/customers" element={<CustomersPage />} />
        <Route path="/expenses" element={<ExpensesPage />} />
        <Route path="/girvi" element={<GirviPage />} />
        <Route path="/inventory" element={<InventoryPage />} />
        <Route path="/karigars" element={<KarigarsPage />} />
        <Route path="/purchases" element={<PurchasesPage />} />
        <Route path="/repairs" element={<RepairsPage />} />
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/sales" element={<SalesPage />} />
        <Route path="/suppliers" element={<SuppliersPage />} />
        <Route path="/gold-rates" element={<GoldRatesPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/ledger" element={<LedgerPage />} />
        <Route path="/dues" element={<DuesPage />} />
        <Route path="/forwarded-shops" element={<ForwardedShopsPage />} />
        <Route path="/karigar-tasks" element={<KarigarTasksPage />} />
        <Route path="/catalog" element={<CatalogPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/employees" element={<EmployeesPage />} />
        <Route path="/calculator" element={<CalculatorPage />} />
        <Route path="/gst-report" element={<GstReportPage />} />
        <Route
          path="*"
          element={<div className="flex min-h-screen items-center justify-center text-2xl font-bold text-muted-foreground">404 - Page Not Found</div>}
        />
      </Routes>
    </Suspense>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/superadmin/*" element={<Suspense fallback={fallback}><SuperAdminApp /></Suspense>} />
          <Route path="/*" element={<ShopApp />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

