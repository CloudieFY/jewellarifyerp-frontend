import { toast } from "sonner";
import { getStoredTenantToken, getStoredSuperAdminToken, clearStoredTenantSession, clearStoredSuperAdminSession } from "./auth";

// API Configuration — set VITE_API_URL in your .env (frontend) to point at
// your deployed backend. Falls back to localhost for local development.
const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || "http://localhost:3006/api";

type AuthKind = "tenant" | "superadmin" | "none";

const apiCall = async (endpoint: string, options: RequestInit = {}, authKind: AuthKind = "tenant") => {
  const url = `${API_BASE_URL}${endpoint}`;

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };

  if (authKind === "tenant") {
    const token = getStoredTenantToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  } else if (authKind === "superadmin") {
    const token = getStoredSuperAdminToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(url, { ...options, headers });
  } catch (err: any) {
    console.error(`[API Network Error] ${url}:`, err);
    throw new Error(`Network Error: Cannot connect to the backend server. Is it running?`);
  }

  const contentType = response.headers.get("content-type");
  const isJson = contentType && contentType.includes("application/json");

  if (response.status === 401) {
    // Token missing/expired/invalid — clear the relevant session so the
    // app falls back to its login screen instead of looping on errors.
    if (authKind === "tenant") clearStoredTenantSession();
    if (authKind === "superadmin") clearStoredSuperAdminSession();
  }

  if (!response.ok) {
    const errorData = isJson ? await response.json() : await response.text();
    const errorPayload = isJson ? errorData : { message: errorData };
    console.error(`[API Error] ${url} ${response.status}:`, errorPayload);
    const errorMessage = isJson
      ? errorData.error || errorData.message || JSON.stringify(errorData)
      : `API Error: Endpoint may not exist (${response.status})`;
    toast.error(errorMessage);
    throw new Error(errorMessage);
  }

  if (!isJson) {
    throw new Error(`API Error: Expected JSON but received HTML for ${endpoint}.`);
  }

  return response.json();
};

/* ====================================================================== */
/*  SHOP (TENANT) AUTH                                                    */
/* ====================================================================== */
export const authAPI = {
  login: (shopSlug: string, username: string, password: string) =>
    apiCall("/auth/login", { method: "POST", body: JSON.stringify({ shopSlug, username, password }) }, "none"),
  me: () => apiCall("/auth/me", {}, "tenant"),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiCall("/auth/change-password", { method: "POST", body: JSON.stringify({ currentPassword, newPassword }) }, "tenant"),
  listUsers: () => apiCall("/auth/users", {}, "tenant"),
  createUser: (data: any) => apiCall("/auth/users", { method: "POST", body: JSON.stringify(data) }, "tenant"),
  updateUser: (id: string, data: any) => apiCall(`/auth/users/${id}`, { method: "PUT", body: JSON.stringify(data) }, "tenant"),
  deleteUser: (id: string) => apiCall(`/auth/users/${id}`, { method: "DELETE" }, "tenant"),
};

/* ====================================================================== */
/*  SUPER ADMIN                                                           */
/* ====================================================================== */
export const superAdminAPI = {
  login: (username: string, password: string) =>
    apiCall("/superadmin/login", { method: "POST", body: JSON.stringify({ username, password }) }, "none"),
  me: () => apiCall("/superadmin/me", {}, "superadmin"),
  listShops: () => apiCall("/superadmin/shops", {}, "superadmin"),
  getShop: (id: string) => apiCall(`/superadmin/shops/${id}`, {}, "superadmin"),
  createShop: (data: any) => apiCall("/superadmin/shops", { method: "POST", body: JSON.stringify(data) }, "superadmin"),
  updateShop: (id: string, data: any) => apiCall(`/superadmin/shops/${id}`, { method: "PUT", body: JSON.stringify(data) }, "superadmin"),
  suspendShop: (id: string) => apiCall(`/superadmin/shops/${id}/suspend`, { method: "POST" }, "superadmin"),
  activateShop: (id: string) => apiCall(`/superadmin/shops/${id}/activate`, { method: "POST" }, "superadmin"),
  renewShop: (id: string, newEndDate: string, plan?: string) =>
    apiCall(`/superadmin/shops/${id}/renew`, { method: "POST", body: JSON.stringify({ newEndDate, plan }) }, "superadmin"),
  resetOwnerPassword: (id: string, newPassword: string) =>
    apiCall(`/superadmin/shops/${id}/reset-owner-password`, { method: "POST", body: JSON.stringify({ newPassword }) }, "superadmin"),
  deleteShop: (id: string) => apiCall(`/superadmin/shops/${id}`, { method: "DELETE" }, "superadmin"),
};

/* ====================================================================== */
/*  TENANT BUSINESS DATA — every call automatically carries the shop's    */
/*  JWT, so the backend always scopes these to the caller's own shop DB.  */
/* ====================================================================== */

export const customerAPI = {
  getAll: () => apiCall("/customers"),
  getById: (id: string) => apiCall(`/customers/${id}`),
  create: (data: any) => apiCall("/customers", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/customers/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/customers/${id}`, { method: "DELETE" }),
};

export const supplierAPI = {
  getAll: () => apiCall("/suppliers"),
  getById: (id: string) => apiCall(`/suppliers/${id}`),
  create: (data: any) => apiCall("/suppliers", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/suppliers/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/suppliers/${id}`, { method: "DELETE" }),
};

export const inventoryAPI = {
  getAll: () => apiCall("/inventory"),
  getById: (id: string) => apiCall(`/inventory/${id}`),
  create: (data: any) => apiCall("/inventory", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/inventory/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/inventory/${id}`, { method: "DELETE" }),
};

export const salesAPI = {
  getAll: () => apiCall("/sales"),
  getById: (id: string) => apiCall(`/sales/${id}`),
  create: (data: any) => apiCall("/sales", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/sales/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/sales/${id}`, { method: "DELETE" }),
};

export const purchasesAPI = {
  getAll: () => apiCall("/purchases"),
  getById: (id: string) => apiCall(`/purchases/${id}`),
  create: (data: any) => apiCall("/purchases", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/purchases/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/purchases/${id}`, { method: "DELETE" }),
};

export const expensesAPI = {
  getAll: () => apiCall("/expenses"),
  getById: (id: string) => apiCall(`/expenses/${id}`),
  create: (data: any) => apiCall("/expenses", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/expenses/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/expenses/${id}`, { method: "DELETE" }),
};

export const karigarsAPI = {
  getAll: () => apiCall("/karigars"),
  getById: (id: string) => apiCall(`/karigars/${id}`),
  create: (data: any) => apiCall("/karigars", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/karigars/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/karigars/${id}`, { method: "DELETE" }),
};

export const jobworkAPI = {
  getAll: () => apiCall("/jobwork"),
  getById: (id: string) => apiCall(`/jobwork/${id}`),
  create: (data: any) => apiCall("/jobwork", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/jobwork/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/jobwork/${id}`, { method: "DELETE" }),
};

export const repairsAPI = {
  getAll: () => apiCall("/repairs"),
  getById: (id: string) => apiCall(`/repairs/${id}`),
  create: (data: any) => apiCall("/repairs", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/repairs/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/repairs/${id}`, { method: "DELETE" }),
};

export const invoicesAPI = {
  getAll: () => apiCall("/invoices"),
  getById: (id: string) => apiCall(`/invoices/${id}`),
  create: (data: any) => apiCall("/invoices", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/invoices/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/invoices/${id}`, { method: "DELETE" }),
};

export const goldRatesAPI = {
  getAll: () => apiCall("/gold-rates"),
  getById: (id: string) => apiCall(`/gold-rates/${id}`),
  create: (data: any) => apiCall("/gold-rates", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/gold-rates/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/gold-rates/${id}`, { method: "DELETE" }),
};

export const schemesAPI = {
  getAll: () => apiCall("/schemes"),
  getById: (id: string) => apiCall(`/schemes/${id}`),
  create: (data: any) => apiCall("/schemes", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/schemes/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/schemes/${id}`, { method: "DELETE" }),
};

export const advancesAPI = {
  getAll: () => apiCall("/advances"),
  getById: (id: string) => apiCall(`/advances/${id}`),
  create: (data: any) => apiCall("/advances", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/advances/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/advances/${id}`, { method: "DELETE" }),
};

export const girviAPI = {
  getAll: () => apiCall("/girvi"),
  getById: (id: string) => apiCall(`/girvi/${id}`),
  create: (data: any) => {
    const payload = { ...data };
    delete payload.id;
    delete payload._id;
    return apiCall("/girvi", { method: "POST", body: JSON.stringify(payload) });
  },
  update: (id: string, data: any) => {
    const payload = { ...data };
    delete payload.id;
    delete payload._id;
    return apiCall(`/girvi/${id}`, { method: "PUT", body: JSON.stringify(payload) });
  },
  delete: (id: string) => apiCall(`/girvi/${id}`, { method: "DELETE" }),
};

export const ordersAPI = {
  getAll: () => apiCall("/orders"),
  getById: (id: string) => apiCall(`/orders/${id}`),
  create: (data: any) => {
    const payload = { ...data };
    delete payload.id;
    delete payload._id;
    return apiCall("/orders", { method: "POST", body: JSON.stringify(payload) });
  },
  update: (id: string, data: any) => {
    const payload = { ...data };
    delete payload.id;
    delete payload._id;
    return apiCall(`/orders/${id}`, { method: "PUT", body: JSON.stringify(payload) });
  },
  delete: (id: string) => apiCall(`/orders/${id}`, { method: "DELETE" }),
};

export const employeesAPI = {
  getAll: () => apiCall("/employees"),
  getById: (id: string) => apiCall(`/employees/${id}`),
  create: (data: any) => apiCall("/employees", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => apiCall(`/employees/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) => apiCall(`/employees/${id}`, { method: "DELETE" }),
};
