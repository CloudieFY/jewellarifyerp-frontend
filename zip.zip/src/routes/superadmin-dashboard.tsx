import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ShieldCheck,
  Plus,
  Store,
  LogOut,
  Copy,
  Check,
  Pause,
  Play,
  RefreshCw,
  KeyRound,
  Trash2,
  Gem,
} from "lucide-react";
import { toast } from "sonner";
import { superAdminAPI } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatDate } from "@/lib/utils";

type Shop = {
  id: string;
  slug: string;
  shopName: string;
  ownerName?: string;
  email?: string;
  phone?: string;
  plan: string;
  status: "active" | "suspended" | "expired";
  subscriptionStartDate: string;
  subscriptionEndDate: string;
  dbName: string;
  createdAt: string;
};

const emptyForm = {
  slug: "",
  shopName: "",
  ownerName: "",
  email: "",
  phone: "",
  address: "",
  gstNumber: "",
  plan: "trial",
  subscriptionEndDate: "",
  adminUsername: "",
  adminPassword: "",
};

export default function SuperAdminDashboardPage() {
  const { superAdminSession, logoutSuperAdmin } = useAuth();
  const navigate = useNavigate();

  const [shops, setShops] = useState<Shop[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [credentialsResult, setCredentialsResult] = useState<{
    loginId: string;
    username: string;
    password: string;
    shopName: string;
  } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const [renewTarget, setRenewTarget] = useState<Shop | null>(null);
  const [renewDate, setRenewDate] = useState("");
  const [resetTarget, setResetTarget] = useState<Shop | null>(null);
  const [newPassword, setNewPassword] = useState("");

  useEffect(() => {
    console.log("[SuperAdminDashboard] session", {
      hasSession: !!superAdminSession,
      adminName: superAdminSession?.admin?.name,
    });
    if (!superAdminSession) {
      navigate("/superadmin/login");
      return;
    }
    loadShops();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [superAdminSession]);

  // Defensive: if API is unreachable or throws, show something instead of a blank screen.
  // This avoids the “white page” symptom when backend URL/CORS is misconfigured.
  // (We keep the existing toast behavior in api.ts for non-200 responses.)


  async function loadShops() {
    setIsLoading(true);
    try {
      console.log("[SuperAdminDashboard] loadShops start");
      const data = await superAdminAPI.listShops();
      console.log("[SuperAdminDashboard] loadShops success", { count: data?.length });
      setShops(data);
    } catch (err: any) {
      console.error("[SuperAdminDashboard] loadShops failed", err);
      // Show a visible error rather than leaving the page blank.
      toast.error(err?.message || "Failed to load shops");
      setShops([]);
    } finally {
      setIsLoading(false);
    }
  }

  async function handleCreateShop(e: React.FormEvent) {
    e.preventDefault();
    console.log("[SuperAdminDashboard] createShop submit", {
      shopName: form.shopName,
      slug: form.slug,
      plan: form.plan,
    });
    setIsSubmitting(true);
    try {
      const result = await superAdminAPI.createShop(form);
      console.log("[SuperAdminDashboard] createShop success", {
        shopId: result.shop?.id,
        shopName: result.shop?.shopName,
      });
      toast.success(`Shop "${result.shop.shopName}" created successfully!`);
      setCredentialsResult({
        loginId: result.loginCredentials.loginId,
        username: result.loginCredentials.username,
        password: result.loginCredentials.password,
        shopName: result.shop.shopName,
      });
      setCreateOpen(false);
      setForm({ ...emptyForm });
      loadShops();
    } catch (err) {
      console.error("[SuperAdminDashboard] createShop failed", err);
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleSuspend(shop: Shop) {
    try {
      await superAdminAPI.suspendShop(shop.id);
      toast.success(`${shop.shopName} suspended`);
      loadShops();
    } catch (err) {
      console.error(err);
    }
  }

  async function handleActivate(shop: Shop) {
    try {
      await superAdminAPI.activateShop(shop.id);
      toast.success(`${shop.shopName} activated`);
      loadShops();
    } catch (err) {
      console.error(err);
    }
  }

  async function handleRenew(e: React.FormEvent) {
    e.preventDefault();
    if (!renewTarget || !renewDate) return;
    try {
      await superAdminAPI.renewShop(renewTarget.id, renewDate);
      toast.success(`Subscription renewed for ${renewTarget.shopName}`);
      setRenewTarget(null);
      setRenewDate("");
      loadShops();
    } catch (err) {
      console.error(err);
    }
  }

  async function handleResetPassword(e: React.FormEvent) {
    e.preventDefault();
    if (!resetTarget || !newPassword) return;
    try {
      await superAdminAPI.resetOwnerPassword(resetTarget.id, newPassword);
      toast.success(`Owner password reset for ${resetTarget.shopName}`);
      setResetTarget(null);
      setNewPassword("");
    } catch (err) {
      console.error(err);
    }
  }

  async function handleDelete(shop: Shop) {
    if (!confirm(`Delete "${shop.shopName}" from the platform registry? Their data will NOT be erased automatically.`)) return;
    try {
      const result = await superAdminAPI.deleteShop(shop.id);
      toast.success(result.message || "Shop deleted");
      loadShops();
    } catch (err) {
      console.error(err);
    }
  }

  function copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 1500);
  }

  function statusBadge(shop: Shop) {
    const expired = new Date(shop.subscriptionEndDate) < new Date();
    if (shop.status === "suspended") {
      return <Badge variant="destructive">Suspended</Badge>;
    }
    if (shop.status === "expired" || expired) {
      return <Badge className="bg-amber-500/15 text-amber-600 border-amber-500/30">Expired</Badge>;
    }
    return <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">Active</Badge>;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-linear-to-tr from-amber-500 to-amber-400 text-slate-950 rounded-xl flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-display text-lg leading-none">Super Admin</div>
              <div className="text-xs text-slate-400 mt-0.5">{superAdminSession?.admin.name}</div>
            </div>
          </div>
          <Button
            variant="ghost"
            className="text-slate-400 hover:text-white hover:bg-slate-800"
            onClick={() => {
              logoutSuperAdmin();
              navigate("/superadmin/login");
            }}
          >
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-display">Shops</h1>
            <p className="text-slate-400 text-sm mt-1">{shops.length} shop{shops.length !== 1 ? "s" : ""} on the platform</p>
          </div>
          <Button onClick={() => setCreateOpen(true)} className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold">
            <Plus className="w-4 h-4 mr-2" /> New Shop
          </Button>
        </div>

        {isLoading ? (
          <div className="text-slate-400 text-center py-16">Loading shops...</div>
        ) : shops.length === 0 ? (
          <Card className="bg-slate-900/60 border-slate-800">
            <CardContent className="py-16 text-center">
              <Store className="w-12 h-12 mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400">No shops yet. Create your first shop to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {shops.map((shop) => (
              <Card key={shop.id} className="bg-slate-900/60 border-slate-800 hover:border-slate-700 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center">
                        <Gem className="w-4 h-4 text-amber-400" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{shop.shopName}</CardTitle>
                        <CardDescription className="text-xs">{shop.slug}</CardDescription>
                      </div>
                    </div>
                    {statusBadge(shop)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-xs text-slate-400 space-y-1">
                    {shop.ownerName && <div>Owner: <span className="text-slate-300">{shop.ownerName}</span></div>}
                    {shop.email && <div>Email: <span className="text-slate-300">{shop.email}</span></div>}
                    <div>Plan: <span className="text-slate-300 capitalize">{shop.plan}</span></div>
                    <div>Expires: <span className="text-slate-300">{formatDate(shop.subscriptionEndDate)}</span></div>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                    {shop.status === "suspended" ? (
                      <Button size="sm" variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800" onClick={() => handleActivate(shop)}>
                        <Play className="w-3.5 h-3.5 mr-1.5" /> Activate
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800" onClick={() => handleSuspend(shop)}>
                        <Pause className="w-3.5 h-3.5 mr-1.5" /> Suspend
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-slate-700 text-slate-300 hover:bg-slate-800"
                      onClick={() => {
                        setRenewTarget(shop);
                        setRenewDate(shop.subscriptionEndDate?.slice(0, 10) || "");
                      }}
                    >
                      <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Renew
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-slate-700 text-slate-300 hover:bg-slate-800"
                      onClick={() => setResetTarget(shop)}
                    >
                      <KeyRound className="w-3.5 h-3.5 mr-1.5" /> Reset PW
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-rose-900 text-rose-400 hover:bg-rose-950 ml-auto"
                      onClick={() => handleDelete(shop)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Shop</DialogTitle>
            <DialogDescription>
              This provisions a brand new, fully isolated database for this shop automatically.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateShop} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2">
                <Label>Shop Name *</Label>
                <Input required value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} placeholder="Arihant Jewellers" />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label>Shop ID (slug) *</Label>
                <Input
                  required
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase().replace(/\s+/g, "-") })}
                  placeholder="arihant-jewellers"
                />
                <p className="text-xs text-muted-foreground">Used by the shop to log in. Lowercase, no spaces.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Owner Name</Label>
                <Input value={form.ownerName} onChange={(e) => setForm({ ...form, ownerName: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label>Email</Label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label>Address</Label>
                <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>GST Number</Label>
                <Input value={form.gstNumber} onChange={(e) => setForm({ ...form, gstNumber: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Plan</Label>
                <Select value={form.plan} onValueChange={(v) => setForm({ ...form, plan: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="trial">Trial</SelectItem>
                    <SelectItem value="basic">Basic</SelectItem>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label>Subscription End Date</Label>
                <Input type="date" value={form.subscriptionEndDate} onChange={(e) => setForm({ ...form, subscriptionEndDate: e.target.value })} />
                <p className="text-xs text-muted-foreground">Leave blank for a 30-day trial.</p>
              </div>
              <div className="col-span-2 border-t pt-4 mt-2">
                <p className="text-sm font-medium mb-3">Owner login (for the shop)</p>
              </div>
              <div className="space-y-1.5">
                <Label>Admin Username *</Label>
                <Input required value={form.adminUsername} onChange={(e) => setForm({ ...form, adminUsername: e.target.value })} placeholder="owner" />
              </div>
              <div className="space-y-1.5">
                <Label>Admin Password *</Label>
                <Input required type="text" minLength={6} value={form.adminPassword} onChange={(e) => setForm({ ...form, adminPassword: e.target.value })} placeholder="min. 6 characters" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={isSubmitting}>{isSubmitting ? "Creating..." : "Create Shop"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!credentialsResult} onOpenChange={() => setCredentialsResult(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Shop Created Successfully</DialogTitle>
            <DialogDescription>
              Share these login details with {credentialsResult?.shopName}. The password is shown only once.
            </DialogDescription>
          </DialogHeader>
          {credentialsResult && (
            <div className="space-y-3">
              {[
                { label: "Shop ID", value: credentialsResult.loginId },
                { label: "Username", value: credentialsResult.username },
                { label: "Password", value: credentialsResult.password },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between bg-muted rounded-lg px-4 py-3">
                  <div>
                    <div className="text-xs text-muted-foreground">{row.label}</div>
                    <div className="font-mono font-medium">{row.value}</div>
                  </div>
                  <Button size="icon" variant="ghost" onClick={() => copyToClipboard(row.value, row.label)}>
                    {copied === row.label ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setCredentialsResult(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!renewTarget} onOpenChange={() => setRenewTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Renew Subscription</DialogTitle>
            <DialogDescription>{renewTarget?.shopName}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRenew} className="space-y-4">
            <div className="space-y-1.5">
              <Label>New End Date</Label>
              <Input type="date" required value={renewDate} onChange={(e) => setRenewDate(e.target.value)} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setRenewTarget(null)}>Cancel</Button>
              <Button type="submit">Renew</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resetTarget} onOpenChange={() => setResetTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Reset Owner Password</DialogTitle>
            <DialogDescription>{resetTarget?.shopName}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div className="space-y-1.5">
              <Label>New Password</Label>
              <Input type="text" required minLength={6} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="min. 6 characters" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setResetTarget(null)}>Cancel</Button>
              <Button type="submit">Reset Password</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
