import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck, Lock, User, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";
import { superAdminAPI } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function SuperAdminLoginPage() {
  const { setSuperAdminSession } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("[SuperAdminLogin] submit", { username: username.trim() });
    setIsLoading(true);
    try {
      const result = await superAdminAPI.login(username.trim(), password);
      console.log("[SuperAdminLogin] login success", {
        adminId: (result as any).admin?.id,
        adminName: (result as any).admin?.name,
      });
      setSuperAdminSession({ token: result.token, admin: result.admin });
      toast.success(`Welcome back, ${result.admin.name}!`);
      navigate("/superadmin");
    } catch (err) {
      console.error("[SuperAdminLogin] login failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-slate-950 via-slate-900 to-slate-950 p-4 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <Card className="w-full max-w-md shadow-2xl border-slate-800 relative z-10 backdrop-blur-sm bg-slate-900/95 text-slate-100">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-14 h-14 bg-linear-to-tr from-amber-500 to-amber-400 text-slate-950 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <CardTitle className="text-3xl font-display tracking-tight text-white">Super Admin</CardTitle>
          <CardDescription className="text-base mt-2 text-slate-400">Platform control panel</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-slate-300">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  id="username"
                  type="text"
                  placeholder="superadmin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  autoFocus
                  className="h-12 pl-10 bg-slate-800/60 border-slate-700 text-white placeholder:text-slate-500 focus:bg-slate-800"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-300">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-12 pl-10 pr-10 bg-slate-800/60 border-slate-700 text-white placeholder:text-slate-500 focus:bg-slate-800"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full h-12 text-base font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md hover:shadow-lg transition-all duration-200 mt-4"
              disabled={isLoading}
            >
              {isLoading ? "Authenticating..." : "Sign In"}
            </Button>
          </form>
        </CardContent>
        <div className="px-6 pb-6 text-center">
          <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to shop login
          </Link>
        </div>
      </Card>
    </div>
  );
}
