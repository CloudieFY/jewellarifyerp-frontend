import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Gem, Lock, User, Store as StoreIcon, Eye, EyeOff, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { authAPI } from "@/lib/api";
import { useAuth, type TenantSession } from "@/lib/auth";

/**
 * Shop login screen.
 *
 * Unlike the old single-tenant app (which had a hardcoded admin/operator
 * username+password baked into the frontend code), every shop now has its
 * own Shop ID (set by the Super Admin when the shop is created) plus its
 * own username/password for each staff login. The backend uses the Shop ID
 * to find the correct isolated database before checking the password.
 */
export default function LoginPage({ onLogin }: { onLogin: (session: TenantSession) => void }) {
  const { setTenantSession } = useAuth();
  const [shopSlug, setShopSlug] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const result = await authAPI.login(shopSlug.trim(), username.trim(), password);
      const session: TenantSession = { token: result.token, user: result.user, shop: result.shop };
      setTenantSession(session);

      // Keep the legacy "ajms.auth" key in sync for the rest of the app,
      // which reads { role, id, name } directly from local storage.
      localStorage.setItem(
        "ajms.auth",
        JSON.stringify({
          role: session.user.role,
          id: session.user.id,
          name: session.user.name,
          karigarRefId: session.user.karigarRefId,
        })
      );

      toast.success(`Welcome ${session.user.name}!`);
      onLogin(session);
    } catch (err) {
      // apiCall already shows a toast with the server's error message
      console.error("Login failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-background via-muted/50 to-muted p-4 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

      <Card className="w-full max-w-md shadow-2xl border-border/50 relative z-10 backdrop-blur-sm bg-card/95">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-14 h-14 bg-linear-to-tr from-primary to-primary/70 text-primary-foreground rounded-2xl flex items-center justify-center mb-6 shadow-lg transform rotate-3 hover:rotate-0 transition-all duration-300">
            <Gem className="w-7 h-7" />
          </div>
          <CardTitle className="text-3xl font-display tracking-tight">JewelShop SaaS</CardTitle>
          <CardDescription className="text-base mt-2">Sign in to your shop</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="shopSlug">Shop ID</Label>
              <div className="relative">
                <StoreIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="shopSlug"
                  type="text"
                  placeholder="e.g. arihant-jewellers"
                  value={shopSlug}
                  onChange={(e) => setShopSlug(e.target.value)}
                  required
                  autoFocus
                  className="h-12 pl-10 bg-background/50 focus:bg-background transition-colors"
                />
              </div>
              <p className="text-xs text-muted-foreground">Given to you by your platform administrator when your shop was set up.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="h-12 pl-10 bg-background/50 focus:bg-background transition-colors"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-12 pl-10 pr-10 bg-background/50 focus:bg-background transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full h-12 text-base font-semibold shadow-md hover:shadow-lg transition-all duration-200 mt-4" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>
        </CardContent>
        <div className="px-6 pb-6 text-center">
          <Link
            to="/superadmin/login"
            className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <ShieldCheck className="w-3.5 h-3.5" /> Platform Super Admin login
          </Link>
        </div>
        <div className="text-center pb-6 text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} JewelShop SaaS. All rights reserved.
        </div>
      </Card>
    </div>
  );
}
